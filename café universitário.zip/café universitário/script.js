
    const videoPlayer = document.querySelector(".videoPlayer");
    const video = videoPlayer.querySelector("#homevideo");
    const playBtn = videoPlayer.querySelector(".playBtn");
    
    playBtn.addEventListener('click', (e) => {
        if (video.paused){
            video.play();
            playBtn.style.opacity = "1"
        } else {
            video.load();
            video.pause();
            playBtn.style.opacity = "0"
        }
    })

    const scrollContainer = document.querySelector(".containerBlend");

scrollContainer.addEventListener("wheel", (evt) => {
    evt.preventDefault();
    scrollContainer.scrollLeft += evt.deltaY *100;
    
});

function toggleMenu() {
  var x = document.getElementById("menu");
  if (x.className === "menu") {
    x.className += " responsive";
  } else {
    x.className = "menu";
  }
}